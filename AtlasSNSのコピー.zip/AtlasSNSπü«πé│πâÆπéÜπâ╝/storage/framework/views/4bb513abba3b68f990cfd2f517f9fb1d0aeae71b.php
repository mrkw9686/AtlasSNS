<?php $__env->startSection('content'); ?>
<h2>機能を実装していきましょう。</h2>
<?php echo Form::open(['url' => 'post/create']); ?>

     <div class="form-group">
       <img src="<?php echo e(asset('images/icon1.png')); ?>">
         <?php echo Form::input('text', 'newPost', null, ['required', 'class' => 'form-control', 'placeholder' => '投稿内容を入力してください。']); ?>

     </div>
     <button type="submit" class="btn btn-success pull-right"><img src="<?php echo e(asset('images/post.png')); ?>"></button>
 <?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/AtlasSNS/AtlasSNS/resources/views/posts/index.blade.php ENDPATH**/ ?>