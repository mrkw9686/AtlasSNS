<?php $__env->startSection('content'); ?>
<h2>機能を実装していきましょう。</h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>