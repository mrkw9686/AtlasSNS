<?php $__env->startSection('content'); ?>

<?php echo Form::open(['url' => 'post/create']); ?>

     <div class="form-group">
       <img src="<?php echo e(asset('images/icon1.png')); ?>">
         <?php echo Form::input('text', 'newPost', null, ['required', 'class' => 'form-control', 'placeholder' => '投稿内容を入力してください。']); ?>

     </div>
     <button type="submit" class="btn btn-success pull-right"><img src="<?php echo e(asset('images/post.png')); ?>"></button>
 <?php echo Form::close(); ?>


       <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="post-block">
       <tr>
          <td><?php echo e($list->id); ?></td>
          <div class="post-content">
 <div class="post-name"><?php echo e($list->user_id); ?></div>

          <div><td><?php echo e($list->created_at); ?></td></div>
          <div><td><?php echo e($list->post); ?></td></div>
</div>


        <a class="js-modal-open" href="" post="<?php echo e($list->post); ?>" post_id="<?php echo e($list->id); ?>"><img src="<?php echo e(asset('images/edit.png')); ?>"></a>

          <a class="btn btn-danger" href="/post/<?php echo e($list->id); ?>/delete" onclick="return confirm('こちらの投稿を削除してもよろしいでしょうか？')">　<img src="<?php echo e(asset('images/trash.png')); ?>"></a>
        </li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <div class="modal js-modal">
        <div class="modal__bg js-modal-close"></div>
        <div class="modal__content">
           <form action="" method="">
                <input type="hidden" name="" class="modal_id" value="">
                <input type="submit" value="更新">
                                <textarea name="" class="modal_post"></textarea>

           </form>
           <a class="js-modal-close" href="">閉じる</a>
        </div>
    </div>
   </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/AtlasSNS/AtlasSNS/resources/views/posts/index.blade.php ENDPATH**/ ?>